package com.example.project;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Random;
public class MainActivity extends AppCompatActivity {
    TextView title;
    TextView allocatedProgram;
    TextView alreadyAllocatedPrograms;
    Button chooseProgarm;
    ArrayList list = new ArrayList();
    Random random = new Random();
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = getApplicationContext();
        title = findViewById(R.id.textView);
        title.setText("This program allocates you experiments from 1 to 15 randomly");
        allocatedProgram = findViewById(R.id.textView2);
        alreadyAllocatedPrograms = findViewById(R.id.textView3);
        chooseProgarm = findViewById(R.id.button);
        chooseProgarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(list.size() < 15) {
                    int allocatedValue = getRandomWithExclusion(random, 1, 15, list);
                    list.add(allocatedValue);
                    allocatedProgram.setText("You have been allocated this program no:" + allocatedValue);
                    alreadyAllocatedPrograms.setText(list.toString());
                }
                else
                {
                    Toast.makeText(context, "All the programs are over",Toast.LENGTH_LONG);
                }
            }
        });
    }
    public int getRandomWithExclusion(Random rnd, int start, int end, ArrayList exclude) {
        int random = start + rnd.nextInt(end - start + 1 - exclude.size());
        for(int i=0;i<exclude.size();i++) {
            if (random < (Integer) exclude.get(i)) {
                break;
            }
            random++;
        }
        return random;
    }
}
